import { motion } from "motion/react";

export default function Hero() {
  const titleText = "VELOCITY";
  const subtitleText = "BEYOND LIMITS";

  const letterAnimation = {
    hidden: { opacity: 0, y: 50 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 2.5 + i * 0.1,
        duration: 1,
        ease: [0.2, 0.65, 0.3, 0.9],
      },
    }),
  };

  return (
    <div className="relative h-screen w-full overflow-hidden flex flex-col items-center justify-center bg-black">
      {/* Background Video */}
      <div className="absolute inset-0 w-full h-full">
        <video
          className="w-full h-full object-cover"
          autoPlay
          muted
          loop
          playsInline
          src="https://res.cloudinary.com/djsurxemd/video/upload/v1781068808/Red_supercar_unveiled_silk_cloth_202606101046_n3onlt.mp4"
        />
        {/* Seamless edge blending gradients */}
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent z-10" />
        
        {/* Futuristic Grid Overlay */}
        <div className="absolute inset-0 z-0 opacity-[0.15] mix-blend-screen bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_70%_70%_at_50%_50%,#000_20%,transparent_100%)] pointer-events-none" />
      </div>

      {/* Hero Content */}
      <motion.div 
        className="relative z-10 flex flex-col items-center justify-center text-center mt-20"
      >
        {/* Black Screen Overlay for cinematic load */}
        <motion.div
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 2, delay: 1 }}
          className="fixed inset-0 bg-black z-50 pointer-events-none"
        />

        <motion.div
           initial={{ opacity: 0, scale: 0.8 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 2, delay: 2, ease: [0.16, 1, 0.3, 1] }}
           className="w-[2px] h-24 bg-gradient-to-b from-transparent via-secondary-500 to-transparent mb-8 blur-[1px]"
        />

        <h1 className="font-display font-bold text-5xl md:text-8xl tracking-[0.1em] text-white overflow-hidden flex drop-shadow-2xl">
          {titleText.split("").map((char, i) => (
            <motion.span
              key={i}
              custom={i}
              initial="hidden"
              animate="visible"
              variants={letterAnimation}
            >
              {char}
            </motion.span>
          ))}
        </h1>
        
        <h2 className="font-sans font-light text-xl md:text-3xl tracking-[0.3em] text-accent-200 mt-4 overflow-hidden flex drop-shadow-lg">
          {subtitleText.split("").map((char, i) => (
            <motion.span
              key={i}
              custom={i}
              initial="hidden"
              animate="visible"
              variants={letterAnimation}
              className={char === " " ? "ml-4" : ""}
            >
              {char}
            </motion.span>
          ))}
        </h2>

        <motion.button
          onClick={() => {
            window.scrollTo({
              top: window.innerHeight,
              behavior: "smooth"
            });
          }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4, duration: 1 }}
          className="mt-12 px-8 py-4 glass-panel rounded-full text-sm tracking-widest uppercase hover:bg-white hover:text-black transition-all duration-500 font-medium cursor-none"
        >
          Explore More
        </motion.button>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 4.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10 pointer-events-none"
      >
        <span className="text-xs uppercase tracking-widest text-white/50">Scroll</span>
        <div className="w-[1px] h-12 bg-white/20 overflow-hidden relative">
          <motion.div
            className="w-full h-1/2 bg-white absolute top-0"
            animate={{ y: [0, 48] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
          />
        </div>
      </motion.div>
    </div>
  );
}
