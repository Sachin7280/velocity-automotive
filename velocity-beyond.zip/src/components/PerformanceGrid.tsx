import { motion } from "motion/react";
import { useRef } from "react";

const features = [
  {
    step: "01",
    title: "Adaptive Suspension",
    desc: "Reacts to road conditions in milliseconds, delivering unparalleled comfort and track-level stiffness on demand."
  },
  {
    step: "02",
    title: "Digital Performance",
    desc: "A neural-net powered AI co-pilot analyzing telemetry to optimize power delivery in real time."
  },
  {
    step: "03",
    title: "Signature Lighting",
    desc: "Laser-matrix headlights that adaptively carve out the road ahead, ensuring maximum visibility with striking presence."
  },
  {
    step: "04",
    title: "Carbon Fiber Chassis",
    desc: "Aerospace-grade materials resulting in a 30% reduction in weight and a 50% increase in structural rigidity."
  }
];

export default function PerformanceGrid() {
  return (
    <section id="performance" className="py-32 relative z-10 w-full overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-start">
        
        <div className="sticky top-32">
          <motion.h2 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1 }}
            className="text-5xl md:text-7xl font-display font-medium leading-[1.1] text-white"
          >
            Engineering <br/> The Impossible.
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.3 }}
            className="mt-8 text-xl text-accent-200/60 max-w-md font-light leading-relaxed"
          >
            Shattering the boundaries of physics. Our latest flagship incorporates aerospace technology with artisan craftsmanship.
          </motion.p>
        </div>

        <div className="flex flex-col gap-6">
          {features.map((feat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50, filter: "blur(10px)" }}
              whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.15, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="glass-panel p-10 rounded-3xl relative overflow-hidden group hover:bg-white/5 transition-all duration-700 cursor-default border border-white/5 hover:border-secondary-500/30"
            >
              {/* Scanner Line */}
              <motion.div 
                initial={{ top: "-100%" }}
                whileHover={{ top: "200%" }}
                transition={{ duration: 1.5, ease: "linear", repeat: Infinity }}
                className="absolute left-0 w-full h-1 bg-gradient-to-r from-transparent via-secondary-500 to-transparent opacity-0 group-hover:opacity-50 blur-[2px] z-0"
              />
              
              {/* Corner Accents */}
              <div className="absolute top-0 left-0 w-8 h-8 border-t border-l border-white/20 group-hover:border-secondary-500 transition-colors duration-500 rounded-tl-3xl m-2" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b border-r border-white/20 group-hover:border-secondary-500 transition-colors duration-500 rounded-br-3xl m-2" />

              {/* Glow Effect */}
              <div className="absolute -inset-[1px] bg-gradient-to-br from-secondary-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-2xl -z-10" />
              
              <div className="relative z-10 text-secondary-500 text-sm font-mono tracking-widest mb-6 flex items-center justify-between">
                <span>{feat.step} //</span>
                <span className="text-[10px] text-white/20 group-hover:text-secondary-500/50 transition-colors">SYS.OP.OK</span>
              </div>
              <h3 className="text-2xl font-display font-medium text-white group-hover:text-secondary-300 transition-colors">
                {feat.title}
              </h3>
              <p className="mt-4 text-accent-200/70 font-light leading-relaxed">
                {feat.desc}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
