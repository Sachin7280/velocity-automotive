import { motion } from "motion/react";

export default function Footer() {
  return (
    <footer id="experience" className="relative mt-32 border-t border-white/10 pt-24 pb-12 overflow-hidden z-10 w-full bg-black">
      {/* Test Drive CTA CTA */}
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 text-center mb-32 relative z-10">
        <motion.h2 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="text-5xl md:text-8xl font-display font-bold text-white mb-8"
        >
          EXPERIENCE THE <br /> IMPOSSIBLE.
        </motion.h2>
        
        <motion.button
          onClick={() => alert("Test drive request received! Our luxury concierge will contact you within 24 hours.")}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="mt-8 px-10 py-5 bg-white text-black font-medium tracking-widest uppercase text-sm rounded-full shadow-[0_0_40px_rgba(255,255,255,0.4)] hover:shadow-[0_0_60px_rgba(255,255,255,0.6)] transition-all duration-300 cursor-none"
        >
          Book a Test Drive
        </motion.button>
      </div>

      <div className="max-w-[1600px] mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-4 gap-12 text-sm text-accent-200/50 mb-16 relative z-10">
        <div>
          <h4 className="text-white font-medium mb-6 uppercase tracking-widest text-xs">Velocity Beyond</h4>
          <p className="font-light leading-loose max-w-xs">
            Pushing the boundaries of automotive engineering. Creating masterpieces that defy physics and elevate the human spirit.
          </p>
        </div>
        
        <div>
          <h4 className="text-white font-medium mb-6 uppercase tracking-widest text-xs">Models</h4>
          <ul className="space-y-4 font-light">
            <li><a href="#" className="hover:text-white transition-colors">V-Series</a></li>
            <li><a href="#" className="hover:text-white transition-colors">GT Concept</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Track Only</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-medium mb-6 uppercase tracking-widest text-xs">Corporate</h4>
          <ul className="space-y-4 font-light">
            <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Investors</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-medium mb-6 uppercase tracking-widest text-xs">Stay Updated</h4>
          <div className="flex border-b border-white/20 pb-2">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="bg-transparent text-white w-full outline-none placeholder:text-accent-200/30 font-light"
            />
            <button 
              onClick={() => alert('Thanks for subscribing!')}
              className="text-white uppercase text-xs tracking-widest font-medium hover:text-secondary-500 transition-colors cursor-none"
            >
              Join
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-6 md:px-12 flex flex-col md:flex-row justify-between items-center text-xs text-accent-200/40 uppercase tracking-widest border-t border-white/10 pt-8 relative z-10">
        <p>© 2026 VELOCITY BEYOND. ALL RIGHTS RESERVED.</p>
        <div className="flex gap-6 mt-4 md:mt-0">
          <a href="#" className="hover:text-white transition-colors cursor-none">Privacy</a>
          <a href="#" className="hover:text-white transition-colors cursor-none">Terms</a>
          <a href="#" className="hover:text-white transition-colors cursor-none">Cookies</a>
        </div>
      </div>

      {/* Background glow text */}
      <div className="absolute bottom-[-10%] md:bottom-[-20%] left-0 w-full text-center pointer-events-none opacity-[0.03] select-none z-0">
        <h1 className="text-[15vw] font-display font-bold whitespace-nowrap">VELOCITY</h1>
      </div>
    </footer>
  );
}
