import { useEffect, useRef } from "react";
import { motion, useInView, useSpring, useTransform } from "motion/react";

export default function AnimatedCounter({ 
  value, 
  decimals = 0, 
  suffix = "" 
}: { 
  value: number; 
  decimals?: number; 
  suffix?: string; 
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -100px 0px" });
  
  // A clean, robust spring for counting
  const spring = useSpring(0, { 
    bounce: 0, 
    duration: 2500,
  });
  
  // Format the number dynamically
  const display = useTransform(spring, (current) => 
    parseFloat(current.toFixed(decimals)).toString() + suffix
  );

  useEffect(() => {
    if (inView) {
      spring.set(value);
    }
  }, [inView, spring, value]);

  return <motion.span ref={ref}>{display}</motion.span>;
}
