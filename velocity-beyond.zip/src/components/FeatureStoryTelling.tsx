import { motion } from "motion/react";
import { cn } from "../lib/utils";

const features = [
  {
    title: "Aerodynamics Redefined.",
    desc: "Every vent, wing, and contour serves a precise aerodynamic purpose. Sculpting the wind to generate over 800kg of downforce while maintaining an exceptionally low drag coefficient.",
    img: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&q=80&w=1000",
    reverse: false
  },
  {
    title: "Luxurious Cockpit.",
    desc: "A driver-centric environment forged from hand-stitched Alcantara, exposed carbon fiber, and milled aerospace aluminum. Ergonomics designed strictly for absolute control.",
    img: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80&w=1000",
    reverse: true
  },
  {
    title: "V12 Symphony.",
    desc: "An naturally aspirated heart revving to an ear-shattering 9,500 RPM. A soundscape engineered to evoke pure emotion and unmistakable presence.",
    img: "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=1000",
    reverse: false
  }
];

export default function FeatureStoryTelling() {
  return (
    <section id="interior" className="py-32 w-full max-w-[1600px] mx-auto px-6 md:px-12 relative z-10 flex flex-col gap-32">
      {features.map((feat, i) => (
        <div 
          key={i} 
          className={cn(
            "flex flex-col lg:flex-row items-center gap-16 lg:gap-24",
            feat.reverse ? "lg:flex-row-reverse" : ""
          )}
        >
          {/* Text */}
          <div className="w-full lg:w-1/2 flex flex-col justify-center">
            <motion.h3 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="text-4xl md:text-6xl font-display font-medium text-white mb-6 leading-tight"
            >
              {feat.title}
            </motion.h3>
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-lg md:text-xl font-light text-accent-200/70 leading-relaxed max-w-lg"
            >
              {feat.desc}
            </motion.p>
          </div>

          {/* Image */}
          <div className="w-full lg:w-1/2">
            <motion.div
              initial={{ clipPath: "polygon(0 100%, 100% 100%, 100% 100%, 0 100%)", scale: 1.1 }}
              whileInView={{ clipPath: "polygon(0 0%, 100% 0%, 100% 100%, 0 100%)", scale: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
              className="relative aspect-square md:aspect-video rounded-3xl overflow-hidden glass-panel bg-black/50"
            >
              <motion.img
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.8 }}
                src={feat.img}
                alt={feat.title}
                referrerPolicy="no-referrer"
                loading="lazy"
                crossOrigin="anonymous"
                className="w-full h-full object-cover opacity-80 mix-blend-screen"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            </motion.div>
          </div>
        </div>
      ))}
    </section>
  );
}
