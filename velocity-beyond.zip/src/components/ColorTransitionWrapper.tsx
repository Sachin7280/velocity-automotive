import { motion, useScroll, useTransform } from "motion/react";
import { useRef, ReactNode } from "react";

export default function ColorTransitionWrapper({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"]
  });

  // Black -> Dark Purple -> Pink -> Magenta
  const backgroundColor = useTransform(
    scrollYProgress,
    [0, 0.33, 0.66, 1],
    ["#000000", "#1A001A", "#33001A", "#1a000a"]
  );

  return (
    <motion.div ref={ref} style={{ backgroundColor }} className="w-full relative transition-colors duration-200">
      {children}
    </motion.div>
  );
}
