import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import AnimatedCounter from "./AnimatedCounter";

const stats = [
  { value: 300, suffix: " MPH", label: "Top Speed", decimals: 0 },
  { value: 1200, suffix: " HP", label: "Horsepower", decimals: 0 },
  { value: 2.1, suffix: " SEC", label: "0-60 MPH", decimals: 1 }
];

export default function PinkCarReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start center", "center center"]
  });

  const xText = useTransform(scrollYProgress, [0, 1], ["-100%", "0%"]);
  const opacity = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <div ref={ref} className="relative z-10 w-full min-h-screen bg-black flex flex-col py-32 justify-end">
      {/* 100% Opacity Background Video */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <video
          className="w-full h-full object-cover"
          autoPlay
          muted
          loop
          playsInline
          style={{ opacity: 1 }}
          src="https://res.cloudinary.com/djsurxemd/video/upload/v1781068803/Pink_luxury_supercar_studio_202606101046_apnqzy.mp4"
        />
        {/* Seamless edge blending gradients */}
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-black to-transparent opacity-80" />
      </div>

      <div className="max-w-[1600px] mx-auto px-6 md:px-12 w-full relative z-10 flex flex-col h-full justify-between pb-12">
        <motion.div 
          style={{ x: xText, opacity }}
          className="max-w-xl mt-12 md:mt-24"
        >
          <h2 className="text-4xl md:text-7xl font-display font-medium text-white leading-tight drop-shadow-xl border-l-4 border-secondary-500 pl-6">
            VELOCITY <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-secondary-300 drop-shadow-md">
              BEYOND LIMITS
            </span>
          </h2>
          <p className="mt-6 text-lg text-white font-medium max-w-md drop-shadow-lg ml-6">
            The next evolution in hypercar engineering. Every curve aerodynamic, every detail perfected.
          </p>
        </motion.div>

        {/* Bottom Performance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mt-auto mb-10 pt-20">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: i * 0.2, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="glass-panel p-8 rounded-2xl bg-black/40 backdrop-blur-md border border-white/5 hover:border-white/10 hover:bg-black/60 transition-all duration-500 group cursor-default relative overflow-hidden"
            >
              {/* Subtle hover glow & tech line */}
              <div className="absolute top-0 left-0 w-1 h-full bg-secondary-500 group-hover:shadow-[0_0_20px_#FF0055] transition-all duration-300" />
              <div className="absolute -inset-4 bg-secondary-500/10 opacity-0 group-hover:opacity-100 blur-2xl transition-opacity duration-500 -z-10" />
              
              <h3 className="text-4xl md:text-5xl font-display font-bold text-white group-hover:text-secondary-300 transition-colors">
                <AnimatedCounter value={stat.value} decimals={stat.decimals} suffix={stat.suffix} />
              </h3>
              <p className="text-sm uppercase tracking-widest text-accent-200 mt-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-secondary-500/50 border border-secondary-500" />
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
