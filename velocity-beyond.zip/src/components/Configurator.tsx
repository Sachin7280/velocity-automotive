import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";

const colors = [
  { name: "Rosso Corsa", value: "#FF1744", bg: "bg-[#FF1744]" },
  { name: "Nero Daytona", value: "#111111", bg: "bg-[#111111]" },
  { name: "Giallo Modena", value: "#FFD600", bg: "bg-[#FFD600]" },
  { name: "Bianco Avus", value: "#F5F5F5", bg: "bg-[#F5F5F5]" },
  { name: "Argento Nurburgring", value: "#C0C0C0", bg: "bg-[#C0C0C0]" },
];

export default function Configurator() {
  const [activeColor, setActiveColor] = useState(colors[0]);
  const [isApplying, setIsApplying] = useState(false);
  const [applied, setApplied] = useState(false);

  const handleApply = () => {
    setIsApplying(true);
    setApplied(false);
    setTimeout(() => {
      setIsApplying(false);
      setApplied(true);
      setTimeout(() => setApplied(false), 3000);
    }, 1500);
  };

  return (
    <section id="technology" className="py-32 w-full max-w-[1600px] mx-auto px-6 md:px-12 relative z-10">
      <div className="text-center mb-16">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-sm font-mono tracking-[0.3em] text-secondary-500 uppercase"
        >
          Studio Configurator
        </motion.h2>
        <motion.h3
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-4xl md:text-6xl font-display font-medium text-white mt-4"
        >
          Paint Your Legacy.
        </motion.h3>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-black/20 p-8 md:p-12 rounded-[2rem] border border-white/5 backdrop-blur-3xl">
        
        {/* Render/Viewer */}
        <div className="lg:col-span-8 relative w-full h-[300px] md:h-[500px] flex items-center justify-center rounded-2xl overflow-hidden glass-panel group">
          <AnimatePresence mode="popLayout">
            <motion.div
              key={activeColor.name}
              initial={{ opacity: 0, scale: 0.9, filter: "blur(20px)" }}
              animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, scale: 1.1, filter: "blur(20px)" }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0 flex items-center justify-center"
            >
              {/* Abstract 3D paint sphere replacement since we lack a GLTF */}
              <div 
                className="w-48 h-48 md:w-80 md:h-80 rounded-full shadow-2xl relative"
                style={{ 
                  background: `radial-gradient(circle at 30% 30%, ${activeColor.value}, #000)`,
                  boxShadow: `0 20px 60px -10px ${activeColor.value}80` 
                }}
              >
                {/* Glossy reflection */}
                <div className="absolute top-[10%] left-[15%] w-1/2 h-1/2 bg-white/20 rounded-full blur-md transform -rotate-45" />
              </div>
            </motion.div>
          </AnimatePresence>
          
          <div className="absolute bottom-6 left-0 right-0 text-center text-white/50 text-xs tracking-widest font-mono uppercase">
            Interactive Paint Material <br /> (GLTF Model Replaceable)
          </div>
        </div>

        {/* Controls */}
        <div className="lg:col-span-4 flex flex-col gap-10">
          <div>
            <h4 className="text-xl font-display text-white mb-2">Exterior Paint</h4>
            <p className="text-sm font-mono text-accent-200/50 uppercase tracking-widest">
              {activeColor.name}
            </p>
          </div>

          <div className="flex flex-col gap-4">
            {colors.map((color) => (
              <button
                key={color.name}
                onClick={() => setActiveColor(color)}
                className={cn(
                  "flex items-center gap-4 p-3 rounded-xl transition-all duration-300 cursor-none w-full text-left",
                  activeColor.name === color.name ? "bg-white/10 border-white/20 border" : "hover:bg-white/5 border border-transparent"
                )}
              >
                <div className={cn("w-8 h-8 rounded-full border-2 border-white/20 shadow-inner", color.bg)} />
                <span className={cn(
                  "text-sm font-medium transition-colors",
                  activeColor.name === color.name ? "text-white" : "text-white/50"
                )}>
                  {color.name}
                </span>
              </button>
            ))}
          </div>

          <button 
            onClick={handleApply}
            disabled={isApplying || applied}
            className="mt-8 relative overflow-hidden group border border-white/20 px-6 py-4 rounded-full w-full text-sm uppercase tracking-widest font-medium disabled:opacity-70 disabled:cursor-none cursor-none"
          >
            <span className={cn(
              "relative z-10 transition-colors duration-500",
              (isApplying || applied) ? "text-white" : "group-hover:text-black"
            )}>
              {isApplying ? "Applying..." : applied ? "Configuration Saved ✓" : "Apply Configuration"}
            </span>
            {(!isApplying && !applied) && (
              <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out" />
            )}
          </button>
        </div>

      </div>
    </section>
  );
}
