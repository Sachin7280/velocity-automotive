import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { cn } from "../lib/utils";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className={cn(
        "fixed top-0 left-0 w-full z-50 transition-all duration-500 ease-out border-b border-white/0",
        scrolled ? "glass-panel border-white/5 py-4" : "bg-transparent py-6"
      )}
    >
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 flex items-center justify-between">
        <div className="text-xl font-display font-bold tracking-widest uppercase">
          Velocity
        </div>
        
        <div className="hidden md:flex items-center space-x-10 text-sm font-medium tracking-wider text-accent-200">
          {["Performance", "Technology", "Interior", "Experience"].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} onClick={(e) => {
              e.preventDefault();
              const target = document.getElementById(item.toLowerCase());
              if (target) target.scrollIntoView({ behavior: 'smooth' });
            }} className="hover:text-white transition-colors cursor-none relative group">
              {item}
              <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-secondary-500 transition-all duration-300 group-hover:w-full"></span>
            </a>
          ))}
        </div>

        <button 
          onClick={() => alert("Your reservation spot has been added to our exclusive waitlist. We will contact you shortly.")}
          className="text-sm font-medium tracking-widest uppercase glass-panel px-5 py-2.5 rounded-full hover:bg-white hover:text-black transition-all duration-300 cursor-none"
        >
          Reserve
        </button>
      </div>
    </motion.nav>
  );
}
