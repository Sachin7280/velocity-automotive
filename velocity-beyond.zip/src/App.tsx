/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from "react";
import Lenis from "lenis";

import Navbar from "./layout/Navbar";
import CustomCursor from "./components/CustomCursor";
import Hero from "./components/Hero";
import PinkCarReveal from "./components/PinkCarReveal";
import ColorTransitionWrapper from "./components/ColorTransitionWrapper";
import PerformanceGrid from "./components/PerformanceGrid";
import FeatureStoryTelling from "./components/FeatureStoryTelling";
import Configurator from "./components/Configurator";
import Footer from "./components/Footer";

export default function App() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: "vertical",
      gestureOrientation: "vertical",
      smoothWheel: true,
      touchMultiplier: 2,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-primary-900 overflow-x-hidden cursor-none">
      <CustomCursor />
      <Navbar />
      
      <main>
        {/* Hero section containing the landing red car video */}
        <Hero />
        
        {/* Distinct section containing the pink car video at 100% opacity */}
        <PinkCarReveal />
        
        {/* We wrap the rest of the sections in a color transition wrapper */}
        <ColorTransitionWrapper>
          <PerformanceGrid />
          <FeatureStoryTelling />
          <Configurator />
          <Footer />
        </ColorTransitionWrapper>
      </main>
    </div>
  );
}
